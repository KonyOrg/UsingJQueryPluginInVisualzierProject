define({ 

 //Type your controller code here 
	displayTheCapturedSignature: function () {
      this.view.browserDisplayCapturedSigature.htmlString = "<html><body><div>"+gblCapturedSignature+"</div></body></html>";
    }
 });