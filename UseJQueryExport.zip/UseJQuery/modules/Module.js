//Type your code here

function getSignatureFromJQueryPlugin (capturedSignature) {
  gblCapturedSignature = capturedSignature;
}